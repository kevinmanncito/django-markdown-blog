from django.apps import AppConfig


class BlogConfig(AppConfig):
    name = 'lk.blog'
    verbose_name = "Blog"
